<?php
// require('connection.php');
// $collection_item = $database->selectCollection('item_list');
// $collection = $database->selectCollection('AH');
// $cursor = $collection_item->findOne(array('name' => 'Stormray'));
// $ah = $collection->find(array('item' => $cursor['item']))->sort(array('buyout' => 1))->limit(1);
$text = "<b>Heelo</b>";
print_r(iterator_to_array($ah));


?>